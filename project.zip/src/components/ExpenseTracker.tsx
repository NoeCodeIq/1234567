import React from 'react';
    import { useForm } from 'react-hook-form';
    import { zodResolver } from '@hookform/resolvers/zod';
    import { z } from 'zod';
    import { toast } from 'react-toastify';
    import { Plus, Trash2 } from 'lucide-react';
    import { format } from 'date-fns';

    const expenseSchema = z.object({
      amount: z.number().min(0.01, 'Amount must be greater than 0'),
      category: z.string().min(1, 'Please select a category'),
      description: z.string().min(1, 'Description is required'),
    });

    type ExpenseFormData = z.infer<typeof expenseSchema>;

    export interface Expense {
      id: string;
      amount: number;
      category: string;
      description: string;
      date: string;
    }

    interface ExpenseTrackerProps {
      expenses: Expense[];
      onAddExpense: (expense: Omit<Expense, 'id' | 'date'>) => void;
      onDeleteExpense: (id: string) => void;
    }

    const categories = [
      'housing', 'food', 'transportation', 'entertainment', 
      'utilities', 'healthcare', 'savings', 'other'
    ];

    const ExpenseTracker: React.FC<ExpenseTrackerProps> = ({ 
      expenses, 
      onAddExpense, 
      onDeleteExpense 
    }) => {
      const { register, handleSubmit, reset, formState: { errors } } = useForm<ExpenseFormData>({
        resolver: zodResolver(expenseSchema),
      });

      const onSubmit = (data: ExpenseFormData) => {
        onAddExpense(data);
        reset();
        toast.success('Expense added successfully!');
      };

      return (
        <section className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">Expense Tracker</h2>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                  Amount
                </label>
                <input
                  id="amount"
                  type="number"
                  step="0.01"
                  {...register('amount', { valueAsNumber: true })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0.00"
                />
                {errors.amount && (
                  <p className="mt-1 text-sm text-red-600">{errors.amount.message}</p>
                )}
              </div>

              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                  Category
                </label>
                <select
                  id="category"
                  {...register('category')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select category</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </option>
                  ))}
                </select>
                {errors.category && (
                  <p className="mt-1 text-sm text-red-600">{errors.category.message}</p>
                )}
              </div>

              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <input
                  id="description"
                  type="text"
                  {...register('description')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Expense description"
                />
                {errors.description && (
                  <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
                )}
              </div>
            </div>

            <button
              type="submit"
              className="flex items-center space-x-2 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>Add Expense</span>
            </button>
          </form>

          <div className="space-y-2 max-h-64 overflow-y-auto">
            {expenses.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No expenses recorded yet</p>
            ) : (
              expenses.map((expense) => (
                <div key={expense.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4">
                      <span className="font-medium text-gray-900">${expense.amount.toFixed(2)}</span>
                      <span className="text-sm text-gray-600 capitalize">{expense.category}</span>
                      <span className="text-sm text-gray-500">{expense.description}</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1">
                      {format(new Date(expense.date), 'MMM dd, yyyy HH:mm')}
                    </div>
                  </div>
                  <button
                    onClick={() => onDeleteExpense(expense.id)}
                    className="text-red-600 hover:text-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 rounded-md p-1"
                    aria-label="Delete expense"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </section>
      );
    };

    export default ExpenseTracker;