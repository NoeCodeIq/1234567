import React from 'react';
    import { useForm } from 'react-hook-form';
    import { zodResolver } from '@hookform/resolvers/zod';
    import { z } from 'zod';
    import { toast } from 'react-toastify';

    const budgetSchema = z.object({
      monthlyIncome: z.number().min(0, 'Income must be positive'),
      housing: z.number().min(0, 'Amount must be positive'),
      food: z.number().min(0, 'Amount must be positive'),
      transportation: z.number().min(0, 'Amount must be positive'),
      entertainment: z.number().min(0, 'Amount must be positive'),
      utilities: z.number().min(0, 'Amount must be positive'),
      healthcare: z.number().min(0, 'Amount must be positive'),
      savings: z.number().min(0, 'Amount must be positive'),
      other: z.number().min(0, 'Amount must be positive'),
    });

    type BudgetFormData = z.infer<typeof budgetSchema>;

    interface BudgetSetupProps {
      budget: BudgetFormData;
      onBudgetUpdate: (budget: BudgetFormData) => void;
    }

    const categories = [
      { key: 'housing', label: 'Housing' },
      { key: 'food', label: 'Food' },
      { key: 'transportation', label: 'Transportation' },
      { key: 'entertainment', label: 'Entertainment' },
      { key: 'utilities', label: 'Utilities' },
      { key: 'healthcare', label: 'Healthcare' },
      { key: 'savings', label: 'Savings' },
      { key: 'other', label: 'Other' },
    ];

    const BudgetSetup: React.FC<BudgetSetupProps> = ({ budget, onBudgetUpdate }) => {
      const { register, handleSubmit, formState: { errors } } = useForm<BudgetFormData>({
        resolver: zodResolver(budgetSchema),
        defaultValues: budget,
      });

      const onSubmit = (data: BudgetFormData) => {
        onBudgetUpdate(data);
        toast.success('Budget updated successfully!');
      };

      return (
        <section className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-6">Monthly Budget Setup</h2>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label htmlFor="monthlyIncome" className="block text-sm font-medium text-gray-700 mb-2">
                Total Monthly Income
              </label>
              <input
                id="monthlyIncome"
                type="number"
                step="0.01"
                {...register('monthlyIncome', { valueAsNumber: true })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter your monthly income"
              />
              {errors.monthlyIncome && (
                <p className="mt-1 text-sm text-red-600">{errors.monthlyIncome.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.map(({ key, label }) => (
                <div key={key}>
                  <label htmlFor={key} className="block text-sm font-medium text-gray-700 mb-2">
                    {label}
                  </label>
                  <input
                    id={key}
                    type="number"
                    step="0.01"
                    {...register(key as keyof BudgetFormData, { valueAsNumber: true })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder={`Budget for ${label.toLowerCase()}`}
                  />
                  {errors[key as keyof BudgetFormData] && (
                    <p className="mt-1 text-sm text-red-600">{errors[key as keyof BudgetFormData]?.message}</p>
                  )}
                </div>
              ))}
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-green-600 text-white py-2 px-4 rounded-md hover:from-blue-700 hover:to-green-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
            >
              Update Budget
            </button>
          </form>
        </section>
      );
    };

    export default BudgetSetup;