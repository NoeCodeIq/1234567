import React from 'react';
    import { DollarSign } from 'lucide-react';

    const Header: React.FC = () => {
      return (
        <header className="bg-gradient-to-r from-blue-600 to-green-600 text-white shadow-lg">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-center space-x-3">
              <DollarSign className="h-8 w-8" />
              <h1 className="text-2xl md:text-3xl font-bold">Personal Budget Tracker</h1>
            </div>
          </div>
        </header>
      );
    };

    export default Header;