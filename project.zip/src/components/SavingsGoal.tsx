import React from 'react';
    import { useForm } from 'react-hook-form';
    import { zodResolver } from '@hookform/resolvers/zod';
    import { z } from 'zod';
    import { toast } from 'react-toastify';
    import { Target, TrendingUp } from 'lucide-react';

    const savingsSchema = z.object({
      goalAmount: z.number().min(1, 'Goal amount must be greater than 0'),
      goalName: z.string().min(1, 'Goal name is required'),
    });

    type SavingsFormData = z.infer<typeof savingsSchema>;

    export interface SavingsGoal {
      goalAmount: number;
      goalName: string;
      currentAmount: number;
    }

    interface SavingsGoalProps {
      savingsGoal: SavingsGoal;
      onUpdateGoal: (goal: Omit<SavingsGoal, 'currentAmount'>) => void;
      onAddToSavings: (amount: number) => void;
    }

    const SavingsGoalComponent: React.FC<SavingsGoalProps> = ({ 
      savingsGoal, 
      onUpdateGoal, 
      onAddToSavings 
    }) => {
      const [addAmount, setAddAmount] = React.useState<string>('');
      
      const { register, handleSubmit, formState: { errors } } = useForm<SavingsFormData>({
        resolver: zodResolver(savingsSchema),
        defaultValues: {
          goalAmount: savingsGoal.goalAmount,
          goalName: savingsGoal.goalName,
        },
      });

      const onSubmit = (data: SavingsFormData) => {
        onUpdateGoal(data);
        toast.success('Savings goal updated!');
      };

      const handleAddToSavings = () => {
        const amount = parseFloat(addAmount);
        if (amount > 0) {
          onAddToSavings(amount);
          setAddAmount('');
          toast.success(`$${amount.toFixed(2)} added to savings!`);
        }
      };

      const progressPercentage = savingsGoal.goalAmount > 0 
        ? Math.min((savingsGoal.currentAmount / savingsGoal.goalAmount) * 100, 100)
        : 0;

      return (
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center space-x-2 mb-6">
            <Target className="h-6 w-6 text-green-600" />
            <h2 className="text-xl font-semibold text-gray-800">Savings Goal</h2>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="goalName" className="block text-sm font-medium text-gray-700 mb-2">
                  Goal Name
                </label>
                <input
                  id="goalName"
                  type="text"
                  {...register('goalName')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="e.g., Emergency Fund"
                />
                {errors.goalName && (
                  <p className="mt-1 text-sm text-red-600">{errors.goalName.message}</p>
                )}
              </div>

              <div>
                <label htmlFor="goalAmount" className="block text-sm font-medium text-gray-700 mb-2">
                  Goal Amount
                </label>
                <input
                  id="goalAmount"
                  type="number"
                  step="0.01"
                  {...register('goalAmount', { valueAsNumber: true })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="0.00"
                />
                {errors.goalAmount && (
                  <p className="mt-1 text-sm text-red-600">{errors.goalAmount.message}</p>
                )}
              </div>
            </div>

            <button
              type="submit"
              className="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors"
            >
              Update Goal
            </button>
          </form>

          {savingsGoal.goalName && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-gray-800">{savingsGoal.goalName}</h3>
                  <TrendingUp className="h-5 w-5 text-green-600" />
                </div>
                
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Progress</span>
                  <span className="text-sm font-medium text-gray-800">
                    ${savingsGoal.currentAmount.toFixed(2)} / ${savingsGoal.goalAmount.toFixed(2)}
                  </span>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                  <div
                    className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">{progressPercentage.toFixed(1)}% Complete</span>
                  <span className="text-sm font-medium text-green-600">
                    ${(savingsGoal.goalAmount - savingsGoal.currentAmount).toFixed(2)} remaining
                  </span>
                </div>
              </div>

              <div className="flex space-x-2">
                <input
                  type="number"
                  step="0.01"
                  value={addAmount}
                  onChange={(e) => setAddAmount(e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Amount to add"
                />
                <button
                  onClick={handleAddToSavings}
                  className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                >
                  Add to Savings
                </button>
              </div>
            </div>
          )}
        </section>
      );
    };

    export default SavingsGoalComponent;