import React from 'react';
    import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
    import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
    import type { Expense } from './ExpenseTracker';

    interface BudgetData {
      monthlyIncome: number;
      housing: number;
      food: number;
      transportation: number;
      entertainment: number;
      utilities: number;
      healthcare: number;
      savings: number;
      other: number;
    }

    interface DashboardProps {
      budget: BudgetData;
      expenses: Expense[];
    }

    const Dashboard: React.FC<DashboardProps> = ({ budget, expenses }) => {
      const categories = [
        'housing', 'food', 'transportation', 'entertainment',
        'utilities', 'healthcare', 'savings', 'other'
      ];

      const getSpentByCategory = (category: string) => {
        return expenses
          .filter(expense => expense.category === category)
          .reduce((total, expense) => total + expense.amount, 0);
      };

      const totalBudgeted = categories.reduce((total, category) => 
        total + (budget[category as keyof BudgetData] || 0), 0
      );

      const totalSpent = expenses.reduce((total, expense) => total + expense.amount, 0);
      const remainingBudget = totalBudgeted - totalSpent;

      const categoryData = categories.map(category => {
        const budgeted = budget[category as keyof BudgetData] || 0;
        const spent = getSpentByCategory(category);
        const remaining = budgeted - spent;
        const percentage = budgeted > 0 ? (spent / budgeted) * 100 : 0;

        return {
          category: category.charAt(0).toUpperCase() + category.slice(1),
          budgeted,
          spent,
          remaining,
          percentage: Math.min(percentage, 100),
          isOverBudget: spent > budgeted,
        };
      });

      const chartData = categoryData.map(item => ({
        name: item.category,
        budgeted: item.budgeted,
        spent: item.spent,
      }));

      return (
        <section className="space-y-6">
          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Budgeted</p>
                  <p className="text-2xl font-bold text-gray-900">${totalBudgeted.toFixed(2)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Spent</p>
                  <p className="text-2xl font-bold text-gray-900">${totalSpent.toFixed(2)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Remaining Budget</p>
                  <p className={`text-2xl font-bold ${remainingBudget >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    ${remainingBudget.toFixed(2)}
                  </p>
                </div>
                {remainingBudget >= 0 ? (
                  <TrendingUp className="h-8 w-8 text-green-600" />
                ) : (
                  <TrendingDown className="h-8 w-8 text-red-600" />
                )}
              </div>
            </div>
          </div>

          {/* Category Breakdown */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Category Breakdown</h3>
            <div className="space-y-4">
              {categoryData.map((item) => (
                <div key={item.category} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700">{item.category}</span>
                    <div className="text-sm text-gray-600">
                      <span className={item.isOverBudget ? 'text-red-600' : 'text-gray-900'}>
                        ${item.spent.toFixed(2)}
                      </span>
                      <span className="text-gray-400"> / ${item.budgeted.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${
                        item.isOverBudget ? 'bg-red-500' : 'bg-gradient-to-r from-blue-500 to-green-500'
                      }`}
                      style={{ width: `${Math.min(item.percentage, 100)}%` }}
                    />
                  </div>
                  {item.isOverBudget && (
                    <p className="text-xs text-red-600">Over budget by ${(item.spent - item.budgeted).toFixed(2)}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Spending Chart */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Spending Overview</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 12 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    formatter={(value: number) => [`$${value.toFixed(2)}`, '']}
                    labelStyle={{ color: '#374151' }}
                  />
                  <Bar dataKey="budgeted" fill="#3B82F6" name="Budgeted" />
                  <Bar dataKey="spent" fill="#10B981" name="Spent" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
      );
    };

    export default Dashboard;