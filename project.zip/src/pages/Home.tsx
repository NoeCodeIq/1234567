import React, { useState, useEffect } from 'react';
    import { toast } from 'react-toastify';
    import { RotateCcw, Download } from 'lucide-react';
    import Header from '../components/Header';
    import Footer from '../components/Footer';
    import BudgetSetup from '../components/BudgetSetup';
    import ExpenseTracker, { type Expense } from '../components/ExpenseTracker';
    import Dashboard from '../components/Dashboard';
    import SavingsGoalComponent, { type SavingsGoal } from '../components/SavingsGoal';

    interface BudgetData {
      monthlyIncome: number;
      housing: number;
      food: number;
      transportation: number;
      entertainment: number;
      utilities: number;
      healthcare: number;
      savings: number;
      other: number;
    }

    const defaultBudget: BudgetData = {
      monthlyIncome: 0,
      housing: 0,
      food: 0,
      transportation: 0,
      entertainment: 0,
      utilities: 0,
      healthcare: 0,
      savings: 0,
      other: 0,
    };

    const defaultSavingsGoal: SavingsGoal = {
      goalAmount: 0,
      goalName: '',
      currentAmount: 0,
    };

    const Home: React.FC = () => {
      const [budget, setBudget] = useState<BudgetData>(defaultBudget);
      const [expenses, setExpenses] = useState<Expense[]>([]);
      const [savingsGoal, setSavingsGoal] = useState<SavingsGoal>(defaultSavingsGoal);

      // Load data from localStorage on component mount
      useEffect(() => {
        const savedBudget = localStorage.getItem('budgetTracker_budget');
        const savedExpenses = localStorage.getItem('budgetTracker_expenses');
        const savedSavingsGoal = localStorage.getItem('budgetTracker_savingsGoal');

        if (savedBudget) {
          setBudget(JSON.parse(savedBudget));
        }
        if (savedExpenses) {
          setExpenses(JSON.parse(savedExpenses));
        }
        if (savedSavingsGoal) {
          setSavingsGoal(JSON.parse(savedSavingsGoal));
        }
      }, []);

      // Save data to localStorage whenever state changes
      useEffect(() => {
        localStorage.setItem('budgetTracker_budget', JSON.stringify(budget));
      }, [budget]);

      useEffect(() => {
        localStorage.setItem('budgetTracker_expenses', JSON.stringify(expenses));
      }, [expenses]);

      useEffect(() => {
        localStorage.setItem('budgetTracker_savingsGoal', JSON.stringify(savingsGoal));
      }, [savingsGoal]);

      const handleBudgetUpdate = (newBudget: BudgetData) => {
        setBudget(newBudget);
      };

      const handleAddExpense = (expenseData: Omit<Expense, 'id' | 'date'>) => {
        const newExpense: Expense = {
          ...expenseData,
          id: Date.now().toString(),
          date: new Date().toISOString(),
        };
        setExpenses(prev => [newExpense, ...prev]);
      };

      const handleDeleteExpense = (id: string) => {
        setExpenses(prev => prev.filter(expense => expense.id !== id));
        toast.success('Expense deleted successfully!');
      };

      const handleUpdateSavingsGoal = (goalData: Omit<SavingsGoal, 'currentAmount'>) => {
        setSavingsGoal(prev => ({
          ...goalData,
          currentAmount: prev.currentAmount,
        }));
      };

      const handleAddToSavings = (amount: number) => {
        setSavingsGoal(prev => ({
          ...prev,
          currentAmount: prev.currentAmount + amount,
        }));
      };

      const handleResetData = () => {
        if (window.confirm('Are you sure you want to reset all data? This action cannot be undone.')) {
          setBudget(defaultBudget);
          setExpenses([]);
          setSavingsGoal(defaultSavingsGoal);
          localStorage.removeItem('budgetTracker_budget');
          localStorage.removeItem('budgetTracker_expenses');
          localStorage.removeItem('budgetTracker_savingsGoal');
          toast.success('All data has been reset!');
        }
      };

      const handleExportData = () => {
        const data = {
          budget,
          expenses,
          savingsGoal,
          exportDate: new Date().toISOString(),
        };

        const dataStr = JSON.stringify(data, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = `budget-tracker-export-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        toast.success('Data exported successfully!');
      };

      return (
        <div className="min-h-screen bg-gray-50">
          <Header />
          
          <main className="container mx-auto px-4 py-8">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 space-y-4 lg:space-y-0">
              <div>
                <h2 className="text-2xl font-bold text-gray-800">Budget Overview</h2>
                <p className="text-gray-600">Track your income, expenses, and savings goals</p>
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={handleExportData}
                  className="flex items-center space-x-2 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                >
                  <Download className="h-4 w-4" />
                  <span>Export Data</span>
                </button>
                
                <button
                  onClick={handleResetData}
                  className="flex items-center space-x-2 bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Reset Data</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              <div className="xl:col-span-2 space-y-8">
                <Dashboard budget={budget} expenses={expenses} />
              </div>
              
              <div className="space-y-8">
                <BudgetSetup budget={budget} onBudgetUpdate={handleBudgetUpdate} />
                <SavingsGoalComponent 
                  savingsGoal={savingsGoal}
                  onUpdateGoal={handleUpdateSavingsGoal}
                  onAddToSavings={handleAddToSavings}
                />
              </div>
            </div>

            <div className="mt-8">
              <ExpenseTracker 
                expenses={expenses}
                onAddExpense={handleAddExpense}
                onDeleteExpense={handleDeleteExpense}
              />
            </div>
          </main>

          <Footer />
        </div>
      );
    };

    export default Home;